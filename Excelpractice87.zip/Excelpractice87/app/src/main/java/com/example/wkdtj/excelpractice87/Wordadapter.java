package com.example.wkdtj.excelpractice87;

import android.content.ClipData;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Wordadapter extends RecyclerView.Adapter<Wordadapter.ItemViewHolder>
{
    private ArrayList<Word> mwords;
    Wordadapter(ArrayList<Word> words) { mwords = words; }

    @NonNull
    @Override
    public Wordadapter.ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.word,parent,false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Wordadapter.ItemViewHolder holder, int position) {
        final Word word = mwords.get(position);
        holder.wordname.setText(word.getwordname());
        holder.wordmean.setText(word.getwordmean());
        holder.wordexplain.setText(word.getwordexplain());

    }

    @Override
    public int getItemCount() {
        return mwords.size();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {
        private TextView wordname;
        private TextView wordmean;
        private TextView wordexplain;

        public ItemViewHolder(View itemView) {
            super(itemView);
            wordname = itemView.findViewById(R.id.wordname);
            wordmean = itemView.findViewById(R.id.wordmean);
            wordexplain = itemView.findViewById(R.id.wordexplain);
        }
    }



}

