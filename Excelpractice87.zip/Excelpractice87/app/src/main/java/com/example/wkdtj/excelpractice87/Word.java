package com.example.wkdtj.excelpractice87;

import android.widget.Checkable;

public class Word{
    private String mwordname;
    private String mwordmean;
    private String mwordexplain;

    public void setwordname(String wordname)
    {
        mwordname = wordname;
    }

    public void setwordmean(String wordmean)
    {
        mwordmean = wordmean;
    }

    public void setwordexplain(String wordexplain)
    {
        mwordexplain = wordexplain;
    }



    String getwordname()
    {
        return mwordname;
    }

    String getwordmean()
    {
        return mwordmean;
    }

    String getwordexplain()
    {
        return mwordexplain;
    }



    Word(String wordname, String wordmean, String wordexplain)
    {
        mwordname = wordname;
        mwordmean = wordmean;
        mwordexplain = wordexplain;
    }


}
