package com.example.wkdtj.excelpractice87;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.sax.StartElementListener;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class WordManage extends Activity
{
    //private ArrayList<Word> mwords = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceBundle)
    {
        super.onCreate(savedInstanceBundle);
        setContentView(R.layout.wordmanage);


        final EditText wordname_ed = (EditText) findViewById(R.id.wordname_ed);
        final EditText wordmean_ed = (EditText) findViewById(R.id.wordmean_ed);
        final EditText wordexplain_ed = (EditText) findViewById(R.id.wordexplain_ed);

        Button wordaddButton = (Button) findViewById(R.id.wordadd);
        wordaddButton.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {

                String wordname = wordname_ed.getText().toString();
                String wordmean = wordmean_ed.getText().toString();
                String wordexplain = wordexplain_ed.getText().toString();


                Intent wordexcelintent = new Intent();
                wordexcelintent.putExtra("Wordname",wordname);
                wordexcelintent.putExtra("Wordmean",wordmean);
                wordexcelintent.putExtra("Wordexplain",wordexplain);
                setResult(RESULT_OK, wordexcelintent);
                finish();
            }
        });

        Button worddelButton = (Button) findViewById(R.id.worddel);
        worddelButton.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        Button wordmodButton = (Button) findViewById(R.id.wordmod);
        wordmodButton.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }

}
