package com.example.wkdtj.excelpractice87;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.RequiresApi;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.sl.draw.geom.Context;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class WordExcel extends Activity
{
    int wordresult = 1;
    int Excelresult = 2;
    private ArrayList<Word> mwords;
    private RecyclerView wordRv;
    public Wordadapter itemAdapter;
    String filepath;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.wordactivity);

        wordRv = (RecyclerView) findViewById(R.id.wordlist);
        mwords = new ArrayList<>();


        itemAdapter = new Wordadapter(mwords);
        wordRv.setAdapter(itemAdapter);
        wordRv.setLayoutManager(new LinearLayoutManager(getApplicationContext()));


        //initData();

        Button wordbutton = (Button) findViewById(R.id.word_but);
        wordbutton.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent wordintent = new Intent(WordExcel.this, WordManage.class);
                startActivityForResult(wordintent,1);

            }
        });

        Button excelbutton1 = (Button) findViewById(R.id.excel_button);
        excelbutton1.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {

                saveExcel();
            }
        });

        Button excelbutton2 = (Button) findViewById(R.id.excel_button2);
        excelbutton2.setOnClickListener(new Button.OnClickListener() {
            @TargetApi(Build.VERSION_CODES.KITKAT)
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View v)
            {

                Intent intent = new Intent();
                intent.setType("application/vnd.ms-excel");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent, Excelresult);

                //readExcel(this, filepath);
                /*EditText excel_read_edit = (EditText) findViewById(R.id.exceledit);
                String excel_name = excel_read_edit.getText().toString();
                readExcel(this,excel_name);*/
            }
        });
    }

    /*****************************************************************************************************************************/

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == wordresult)
        {
            if(resultCode == RESULT_OK)
            {
                String wordnameres = data.getStringExtra("Wordname");
                String wordmeanres = data.getStringExtra("Wordmean");
                String wordexplainres = data.getStringExtra("Wordexplain");

                mwords.add(new Word(wordnameres,wordmeanres,wordexplainres));
                itemAdapter.notifyDataSetChanged();

            }
        }
        else if (requestCode == Excelresult)
        {
            if(resultCode == RESULT_OK)
            {
                Uri fileuri = data.getData();
                filepath = getRealPathFromURI(fileuri);
                Toast.makeText(getApplicationContext(), filepath , Toast.LENGTH_LONG).show();
                readExcel((OnClickListener) this,filepath);
            }
        }
    }

    public String getRealPathFromURI(Uri contentUri) {

        String[] proj = { MediaStore.Images.Media.DATA };

        Cursor cursor = getContentResolver().query(contentUri, proj, null, null, null);
        cursor.moveToNext();
        String path = cursor.getString(cursor.getColumnIndex(MediaStore.MediaColumns.DATA));
        Uri uri = Uri.fromFile(new File(path));

        cursor.close();
        return path;
    }

    /*****************************************************************************************************************************/
    private void saveExcel(){
        HSSFWorkbook wordbook = new HSSFWorkbook(); // .xls 확장자를 사용 가능하게 하는 부분

        Sheet sheet = wordbook.createSheet("sheet1"); // 새로운 시트 생성

        Row row = sheet.createRow(0); // 새로운 행 생성
        Cell cell;

        cell = row.createCell(0); // 1번 셀 생성
        cell.setCellValue("이름"); // 1번 셀 값 입력

        cell = row.createCell(1); // 2번 셀 생성
        cell.setCellValue("나이"); // 2번 셀 값 입

        cell = row.createCell(2); // 3번 셀 생성
        cell.setCellValue("뜻"); // 3번 셀 값 입력

        for(int i = 0; i < mwords.size() ; i++) // 리스트뷰의 사이즈 만큼 데이터 입력 반복
        { // 데이터 엑셀에 입력
            row = sheet.createRow(i+1); // 행 생성
            cell = row.createCell(0); // 셀 생성
            cell.setCellValue(mwords.get(i).getwordname()); // 리스트뷰 해당 위치의 값 삽입
            cell = row.createCell(1);
            cell.setCellValue(mwords.get(i).getwordmean());
            cell = row.createCell(2);
            cell.setCellValue(mwords.get(i).getwordexplain());
        }

        final EditText excel_write_edit = (EditText) findViewById(R.id.exceledit); // 여기부분은 나중에 밖으로 뺄 부분
        String excel_name = excel_write_edit.getText().toString();
        String xls_name = ".xls";


        File xlsFile = new File(getExternalFilesDir(null),excel_name + xls_name); // 입력된 엑셀 파일의 이름과 경로를 합침
        try{
            FileOutputStream os = new FileOutputStream(xlsFile); // 파일을 저장할 경로를 저장
            wordbook.write(os); // 외부 저장소에 엑셀 파일 생성
        }catch (IOException e){
            e.printStackTrace(); // 예외 처리
        }
        Toast.makeText(getApplicationContext(),xlsFile.getAbsolutePath()+"에 저장되었습니다",Toast.LENGTH_SHORT).show(); // 경로를 Toast를 이용하여 화면에 보여줌
    }

    /*****************************************************************************************************************************/

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void readExcel(OnClickListener context, String filepath)
    {
        String xls_name = ".xls";

        try {
            //File file = new File(getExternalFilesDir(null),excel_name+xls_name); // 입력된 파일 이름과 경로를 합쳐서 새로운 경로 생성
            FileInputStream fis = new FileInputStream(filepath); // 새로운 경로로 탐색

            POIFSFileSystem fileSystem = new POIFSFileSystem(fis); // 탐색한거 뽑아내고
            HSSFWorkbook wordbook = new HSSFWorkbook(fileSystem); // 뽑아낸거 xls인지 확인하는 뭐 그런거

            int rowindex=0; // 행 인덱스
            int columnindex=0; // 열 인덱스
            HSSFSheet sheet = wordbook.getSheetAt(0); // sheet1에 내용 불러옴
            int rows = sheet.getPhysicalNumberOfRows(); // 행은 그 시트에 있는 행의 수를 대입
            for(rowindex = 1 ; rowindex < rows ; rowindex++) // 행 숫자만큼 반복
            {
                //행을 읽는다
                HSSFRow row = sheet.getRow(rowindex); // 1열부터 시작!
                if(row != null){
                    //셀의 수
                    int cells = row.getPhysicalNumberOfCells(); // 셀의 수는 그 행의 셀의 수를 대입
                    String wordname = null;
                    String wordmean = null;
                    String wordexplain = null;
                    for(columnindex = 0 ; columnindex < cells ; columnindex++) // 0번째 셀부터 있는 셀까지 반복
                    {
                        //셀값을 읽는다
                        HSSFCell cell = row.getCell(columnindex);
                        String word = cell.getStringCellValue(); // 셀에있는 문자 값을 받아옴

                        //String value="";
                        //셀이 빈값일경우를 위한 널체크
                        if(cell==null){
                            continue;
                        }
                        switch (columnindex){ // 0이면 wordname , 1이면 wordmean , 2면 wordexplain 이렇게 대입
                            case 0:
                                wordname = word;
                                break;
                            case 1:
                                wordmean = word;
                                break;
                            case 2:
                                wordexplain = word;
                                break;
                        }
                    }
                    mwords.add(new Word(wordname,wordmean,wordexplain)); // 이제 한개의 열이 끝났으니 리스트뷰에 대입하고
                    itemAdapter.notifyDataSetChanged(); // 대입이 끝났으니 저장
                }
            }

        } catch (FileNotFoundException e) { // 예외 처리
            e.printStackTrace();
        } catch (IOException e) { // 예외처리
            e.printStackTrace();
        }


    }
}

